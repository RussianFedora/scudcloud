from PyQt4.Qt import QApplication

class DummyLauncher:
    def __init__(self, parent):
        self.parent = parent
    def set_property(self, name, value):
        pass
